import { loginAction, signupAction, logoutAction, addCard, getCard } from './actions.js'

const INIT_STATE = {
  authed: false,
  user: {
    login: '',
    password: '',
    name: '',
    surname: ''
  },
  card : {
    number: '',
    name: '',
    date: '',
    cvc: '',
  },
};

const rootReducer = (state = INIT_STATE, action) => {
  switch (action.type) {
    case loginAction.toString():
      return { ...state, 
        authed: true,
        user: {
          login: action.payload.login,
          password: action.payload.password,
        }
      };
    case signupAction.toString():
      return { ...state, 
        authed: true,
        user: {
          login: action.payload.login,
          password: action.payload.password,
          name: action.payload.name,
          surname: action.payload.surname,
        }
      };
    case logoutAction.toString():
      return { ...state, authed: false };
    case addCard.toString():
      return { ...state,
          card : action.payload.card
      };
    case getCard.toString():
      return { ...state };
    default:
      return state;
  }
};

export default rootReducer;