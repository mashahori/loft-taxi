import { createAction } from 'redux-actions';

export const loginAction = createAction('LOG_IN');
export const signupAction = createAction('SIGN_UP');
export const logoutAction = createAction('LOG_OUT');
export const addCard = createAction('ADD_CARD');
export const getCard = createAction('GET_CARD');